package OCA223_Q72_85;

public class Q_84 {
	public static void main(String[] args) {
		
//	int array []=new int[3] {1, 2,3};            //A
//	int array2[] =new int [3]; 					//B
//	array2[0]=1;
//	array2[1]=2;
//	array2[2]=3;
//	
//	int array3[3]=new int[] {1,2,3};			//C
//	int array4[]= new int[3]; array4= {1,2,};	//D
//	int array5[]=new int [] {1,2,3};			//E
	} 

}

//A C
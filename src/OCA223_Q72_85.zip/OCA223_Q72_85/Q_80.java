package OCA223_Q72_85;

public class Q_80 {
	/**
	 * 80. Which two features can be implemented in a Java application by encapsulating the entity classes used?
(Choose two.)

A. data validation
B. compile time polymorphism
C. data hiding
D. data abstraction
E. data memory optimization
Answer: C D
	 */

}

package OCA223_Q61_71;

public class Q_65 {
	public static void main(String[] args) {
        float var1 = (12_345.01 <= 123_45.00)? 12_456 : 124_56.02f;
        float var2 = var1 + 1024;
        System.out.print(var2);
    }

}
//Answer D
/**
 * What is the result?
A. An exception is thrown at runtime.
B. Compilation fails.
C. 13480.0
D. 13480.02
Answer: C
 */
 
